package com.crenildo.gestaousuarios;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestaoUsuariosApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestaoUsuariosApplication.class, args);
	}

}
