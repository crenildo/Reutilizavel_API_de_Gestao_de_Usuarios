package com.crenildo.gestaousuarios;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestaoUsuariosApplicationTests {

	@Test
	void contextLoads() {
	}

}
